package com.example.swaymod;

import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.client.renderer.GlStateManager;

public class SwayDisabler {
    @SubscribeEvent
    public void onRenderHand(RenderHandEvent event) {
        // PERMANENT DISABLE: We don't check for a config or keybind here.
        // This stops the 'bobbing' and 'sway' logic in the render pipeline.
        event.setCanceled(true); 
        
        // SUPPORT FOR 128x128 / TRANSPARENCY:
        // We ensure the alpha blender is on so transparent skins don't look black.
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        
        // Custom render call would go here if you are re-drawing the arm manually
    }
}

