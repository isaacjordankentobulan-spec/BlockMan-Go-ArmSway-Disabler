package com.bmgo.sway;

import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.client.renderer.GlStateManager;

public class SwayDisabler {
    @SubscribeEvent
    public void onRenderHand(RenderHandEvent event) {
        // PERMANENT: No "if" check. This cancels the sway every frame.
        event.setCanceled(true); 
        
        // 128x128 SKIN SUPPORT: 
        // Forces the game to use alpha blending so transparent parts of HD skins don't turn black.
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
    }
}
