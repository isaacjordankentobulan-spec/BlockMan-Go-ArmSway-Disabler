package com.bmgo.sway;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

@Mod(modid = "swaydisabler", name = "BlockMan Go ArmSway Disabler", version = "1.0", acceptedMinecraftVersions = "[1.8]")
public class SwayMain {
    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        // Plugs the permanent disabler into the Forge Event Bus
        MinecraftForge.EVENT_BUS.register(new SwayDisabler());
    }
}
