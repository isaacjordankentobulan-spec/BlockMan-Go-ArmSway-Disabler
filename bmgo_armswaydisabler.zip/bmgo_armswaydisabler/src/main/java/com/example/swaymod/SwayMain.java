package com.example.swaymod;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

@Mod(modid = "swaydisabler", name = "BlockMan Go ArmSway Disabler", version = "1.0")
public class SwayMain {
    
    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        // This line 'activates' your SwayDisabler brain
        MinecraftForge.EVENT_BUS.register(new SwayDisabler());
    }
}
